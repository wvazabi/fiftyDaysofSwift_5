import UIKit


var sum = 0

func doSmth(){
    let num1 = 2
    let num2 = 8
    sum = num1 + num2
}


doSmth()

func doSum(firstNum:Int,secondNum:Int){
    sum = firstNum + secondNum
}

doSum(firstNum: 5, secondNum: 12)

func doSumReturn(number1:Int, number2:Int) -> Int{
    return number1 + number2
}

let sumReturn = doSumReturn(number1: 10, number2: 7)

func sumOfNumber(array:[Int]) -> Int{
    var sum = 0
    for number in array{
        sum += number
    }
    return sum
}
var arrayX = [1,2,3,4,5,6]
sumOfNumber(array: arrayX)

func sumOfNumbers(_ array:[Int]) -> Int{
    var sum = 0
    for number in array{
        sum += number
    }
    return sum
}

sumOfNumbers([2,5,34,654])


var x: Int = 2

var y: Int?

y = 2
//y = nil

var z = x + y!

y = nil

if let nonOptionalY = y {
    var z = x + nonOptionalY
}
else{
    print("y is null!!!")
}

y = 28

func securityMehmet(){
    guard let nonOptionalY = y else { return }
    var z = x + nonOptionalY
}

securityMehmet()

y = nil

var sumz = x + (y ?? 5)
